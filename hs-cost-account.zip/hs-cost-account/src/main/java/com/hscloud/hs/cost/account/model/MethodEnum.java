package com.hscloud.hs.cost.account.model;
public enum MethodEnum {

    GET,
    POST,
    HEAD,
    OPTIONS,
    PUT,
    DELETE,
    TRACE,
    CONNECT,
    PATCH;

    private MethodEnum() {
    }
}
