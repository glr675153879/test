package com.hscloud.hs.cost.account.mapper;

import com.hscloud.hs.cost.account.model.pojo.AdsIncomePerformanceOther;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author author
 * @since 2023-12-07
 */
public interface AdsIncomePerformanceOtherMapper extends BaseMapper<AdsIncomePerformanceOther> {

}
