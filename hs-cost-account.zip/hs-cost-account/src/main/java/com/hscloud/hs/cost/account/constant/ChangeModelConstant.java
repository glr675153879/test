package com.hscloud.hs.cost.account.constant;

/**
 * @author xiechenyu
 * @Description：
 * @date 2024/4/26 16:11
 */
public interface ChangeModelConstant {

    String IMPUTATION_PERSON = "归集人员";
    String SPECIAL_IMPUTATION_PERSON = "特殊归集人员";
    String NON_INCOME_PERSON = "不计收入人员";
    String UNIT_TASK_PROJECT_DETAIL = "单项绩效";
    String UNIT_TASK_DETAIL_ITEM = "科室二次分配";
    String MATERIAL_CHARGE = "物资收费管理";
}
