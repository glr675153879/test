package com.hscloud.hs.cost.account.mapper;

import com.hscloud.hs.cost.account.model.entity.CostVerificationResultIndex;
import com.hscloud.hs.cost.account.model.entity.CostVerificationResultItem;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 小小w
 * @date 2023/11/7 15:10
 */
@Mapper
public interface CostVerificationResultItemMapper extends CostBaseMapper<CostVerificationResultItem>{
}
