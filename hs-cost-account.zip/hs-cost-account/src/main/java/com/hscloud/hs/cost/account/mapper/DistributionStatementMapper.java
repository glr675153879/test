package com.hscloud.hs.cost.account.mapper;

public interface DistributionStatementMapper {


}
