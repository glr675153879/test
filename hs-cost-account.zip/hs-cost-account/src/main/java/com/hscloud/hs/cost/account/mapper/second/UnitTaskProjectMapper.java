package com.hscloud.hs.cost.account.mapper.second;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.second.UnitTaskProject;
import org.apache.ibatis.annotations.Mapper;

/**
* 任务核算指标 Mapper 接口
*
*/
@Mapper
public interface UnitTaskProjectMapper extends BaseMapper<UnitTaskProject> {

}

