package com.hscloud.hs.cost.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.CostAccountPlanConfigFormula;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Admin
 */
@Mapper
public interface CostAccountPlanConfigFormulaMapper extends BaseMapper<CostAccountPlanConfigFormula> {
}
