package com.hscloud.hs.cost.account.mapper.second;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.second.GrantUnitLog;
import org.apache.ibatis.annotations.Mapper;

/**
* 发放单元操作日志 Mapper 接口
*
*/
@Mapper
public interface GrantUnitLogMapper extends BaseMapper<GrantUnitLog> {

}

