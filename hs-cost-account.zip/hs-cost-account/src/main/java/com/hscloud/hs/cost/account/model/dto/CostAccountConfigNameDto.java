package com.hscloud.hs.cost.account.model.dto;

import lombok.Data;

@Data
public class CostAccountConfigNameDto {
    private String name;

    private String accountProportionObject;

    private Long configId;

}
