package com.hscloud.hs.cost.account.mapper;

import com.hscloud.hs.cost.account.model.entity.CostVerificationResultIndexNew;
import com.hscloud.hs.cost.account.model.entity.CostVerificationResultItem;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 小小w
 * @date 2023/11/9 9:14
 */
@Mapper
public interface CostVerificationResultIndexNewMapper extends CostBaseMapper<CostVerificationResultIndexNew>{
}
