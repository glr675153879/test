package com.hscloud.hs.cost.account.constant;

/**
 * @author tianbo
 * @version 1.0
 * @date 2024-09-23 14:05
 **/
public interface DcProgTargetTypeConstants {
    String ALL = null;

    String ALL_NO = "0";

    String TARGET = "1";
}
