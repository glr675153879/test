package com.hscloud.hs.cost.account.controller;


import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

/**
 * <p>
 * 二次分配任务概要表 前端控制器
 * </p>
 *
 * @author 
 * @since 2023-11-17
 */
@RestController
@RequestMapping("/second/distribution/task/summary")
public class SecondDistributionTaskSummaryController {

}
