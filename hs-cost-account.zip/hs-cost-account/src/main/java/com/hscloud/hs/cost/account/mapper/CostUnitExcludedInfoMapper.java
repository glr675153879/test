package com.hscloud.hs.cost.account.mapper;

import com.hscloud.hs.cost.account.model.entity.CostUnitExcludedInfo;
import com.pig4cloud.pigx.common.data.datascope.PigxBaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface CostUnitExcludedInfoMapper extends PigxBaseMapper<CostUnitExcludedInfo> {


}
