package com.hscloud.hs.cost.account.mapper.dataReport;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.dataReport.CostClusterUnit;
import org.apache.ibatis.annotations.Mapper;

/**
* 归集单元 Mapper 接口
*
*/
@Mapper
public interface CostClusterUnitMapper extends BaseMapper<CostClusterUnit> {

}

