package com.hscloud.hs.cost.account.mapper.kpi;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.kpi.KpiId;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface KpiIdMapper extends BaseMapper<KpiId> {
}
