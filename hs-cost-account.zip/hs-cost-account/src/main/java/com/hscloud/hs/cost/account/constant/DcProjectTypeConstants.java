package com.hscloud.hs.cost.account.constant;

/**
 * @author tianbo
 * @version 1.0
 * @date 2024-09-20 14:32
 **/
public interface DcProjectTypeConstants {
    //成本项目
    String COST_PROJECT = "0";

    //分摊参数
    String SHARE_PARAM = "1";
}
