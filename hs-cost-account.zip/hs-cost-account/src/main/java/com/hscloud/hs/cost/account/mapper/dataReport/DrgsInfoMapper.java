package com.hscloud.hs.cost.account.mapper.dataReport;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.dataReport.OdsHisUnidrgswedDboDrgsInfo;
import org.apache.ibatis.annotations.Mapper;

/**
* entity名称未取到 Mapper 接口
*
*/
@Mapper
public interface DrgsInfoMapper extends BaseMapper<OdsHisUnidrgswedDboDrgsInfo> {

}

