package com.hscloud.hs.cost.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.pojo.AdsCostShareTempNew;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface DistributionTaskMapper extends BaseMapper<AdsCostShareTempNew> {
}
