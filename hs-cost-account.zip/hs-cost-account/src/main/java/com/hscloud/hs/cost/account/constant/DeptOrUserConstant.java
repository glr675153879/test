package com.hscloud.hs.cost.account.constant;

/**
 * @author xiechenyu
 * @Description：
 * @date 2024/4/18 10:38
 */
public interface DeptOrUserConstant {
    /*
     *科室
     */
    String DEPT = "DEPT";

    /*
     *人员
     */
    String USER = "USER";

    String DEPT_LIST = "deptList";

    String USER_LIST = "userList";
}
