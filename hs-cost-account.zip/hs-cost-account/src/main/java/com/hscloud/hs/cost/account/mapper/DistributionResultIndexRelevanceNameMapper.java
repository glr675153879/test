package com.hscloud.hs.cost.account.mapper;

import com.hscloud.hs.cost.account.model.entity.DistributionResultIndexRelevanceName;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;

/**
 * <p>
 *  Mapper 接口
 * </p>
 *
 * @author author
 * @since 2023-11-29
 */
public interface DistributionResultIndexRelevanceNameMapper extends BaseMapper<DistributionResultIndexRelevanceName> {

}
