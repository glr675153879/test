package com.hscloud.hs.cost.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.CostTaskExecuteResultExceptionItem;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author 小小w
 * @date 2023/10/30 9:21
 */
@Mapper
public interface CostTaskExecuteResultExceptionItemMapper extends BaseMapper<CostTaskExecuteResultExceptionItem> {
}
