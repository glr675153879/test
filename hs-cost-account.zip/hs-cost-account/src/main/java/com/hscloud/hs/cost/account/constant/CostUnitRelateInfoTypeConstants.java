package com.hscloud.hs.cost.account.constant;

public interface CostUnitRelateInfoTypeConstants {

    String DEPT = "dept";

    String USER = "user";
    String ROLE = "role";
}
