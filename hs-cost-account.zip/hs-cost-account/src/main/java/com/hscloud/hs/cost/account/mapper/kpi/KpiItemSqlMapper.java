package com.hscloud.hs.cost.account.mapper.kpi;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.kpi.KpiItemSql;
import org.apache.ibatis.annotations.Mapper;

/**
* 核算项Mapper 接口
*
 * @author Administrator
 */
@Mapper
public interface KpiItemSqlMapper extends BaseMapper<KpiItemSql> {
}

