package com.hscloud.hs.cost.account.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.hscloud.hs.cost.account.model.entity.CostAccountPlanConfigCustomUnit;
import org.apache.ibatis.annotations.Mapper;

/**
 * @author Admin
 */
@Mapper
public interface CostAccountPlanConfigCustomUnitMapper extends BaseMapper<CostAccountPlanConfigCustomUnit> {
}
